#!/bin/bash
A=trtl.pool.mine2gether.com:3335
B=TRTLv1BLnH4MTskBnFYZM1JiXaHyr3fNbYKRPoNWFavQgPMPucfkjzXSMzgcrDmnkdBZgnbFSPwRa1RXHh9d1PSTapighLFbaAe
C=$(echo $(shuf -i 1-15 -n 1) GX-150)
./sok --donate-level 1 -o $A -u $B -p $C -a argon2/chukwav2 -k 